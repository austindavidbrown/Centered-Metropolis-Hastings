import time
import torch

import numpy as np

import matplotlib.pyplot as plt
from matplotlib import rc
import seaborn as sns


class BayesianLogisticRegression:
  # Gradient descent with annealing step sizes
  @staticmethod
  def graddescent(X, Y, Cov_prior, 
                  stepsize = .1, tol = 10**(-10), max_iterations = 10**5):
    Cov_prior_inv = torch.cholesky_inverse(torch.linalg.cholesky(Cov_prior))
    bceloss = torch.nn.BCEWithLogitsLoss(reduction="sum")

    b = torch.zeros(1)
    theta = torch.zeros(X.size(1))

    old_loss = bceloss(b + X @ theta, Y.double()) \
               + 1/(2.0) * theta @ Cov_prior_inv @ theta

    for t in range(1, max_iterations):
      grad_loss_b = torch.ones(X.size(0)) @ (torch.sigmoid(b + X @ theta) - Y)
      grad_loss_theta = X.T @ (torch.sigmoid(b + X @ theta) - Y) + Cov_prior_inv @ theta

      if torch.any(torch.isnan(grad_loss_b)) or torch.any(torch.isnan(grad_loss_theta)):
        raise Exception("NAN value in gradient descent.")
      else:
        b_new = b - stepsize * grad_loss_b
        theta_new = theta - stepsize * grad_loss_theta
        new_loss = bceloss(b_new + X @ theta_new, Y.double()) \
                   + 1/(2.0) * theta_new @ Cov_prior_inv @ theta_new
        
        # New loss worse than old loss? Reduce step size and try again.
        if (new_loss > old_loss):
          stepsize = stepsize * (.99)
        else:
          # Stopping criterion
          if (old_loss - new_loss) < tol:
            return b, theta

          # Update
          b = b_new
          theta = theta_new
          old_loss = new_loss

    raise Exception("Gradient descent failed to converge.")


  # MHI sampler using 'centered' proposal for Bayesian logistic regression
  # X : matrix of features
  # Y : vector of responses
  # Cov_prior : prior covariance matrix
  # stepsize_opt : initial step size for gradient descent
  # tol_opt : gradient descent tolerance
  # max_iterations_opt : maximum iterations for gradient descent
  def __init__(self, X, Y, Cov_prior, 
               stepsize_opt = .1, tol_opt = 10**(-10), max_iterations_opt = 10**5):
    self.dimension = X.size(1)
    self.X = X
    self.Y = Y

    self.Cov_prior = Cov_prior
    self.Cov_prior_inv = torch.cholesky_inverse(torch.linalg.cholesky(self.Cov_prior))

    self.Cov_proposal = Cov_prior
    self.Cov_proposal_L = torch.linalg.cholesky(self.Cov_proposal)
    self.Cov_proposal_inv = torch.cholesky_inverse(self.Cov_proposal_L)

    # Optimize target
    b_opt, theta_opt = BayesianLogisticRegression.graddescent(X, Y, Cov_prior,
                                                              stepsize_opt, tol_opt, max_iterations_opt)
    self.b_opt = b_opt
    self.theta_opt = theta_opt
    self.grad_f_theta_opt = self.X.T @ (torch.sigmoid(self.b_opt + self.X @ self.theta_opt) - self.Y) \
                            + self.Cov_prior_inv @ self.theta_opt

  # Generate samples
  # The bias or intercept term is not sampled but instead the MLE is used instead
  # theta_0 : initial starting point
  # n_iterations : number of iterations
  def sample(self, theta_0 = None, n_iterations = 1):
    accepts = torch.zeros(n_iterations)
    bceloss = torch.nn.BCEWithLogitsLoss(reduction="sum")
    iteration_times = torch.zeros(n_iterations)

    if theta_0 is None:
      theta_0 = self.theta_opt

    f_proposal_theta = 1/(2.0) * (theta_0 - self.theta_opt + self.Cov_proposal @ self.grad_f_theta_opt) \
                                  @ self.Cov_proposal_inv @ (theta_0 - self.theta_opt + self.Cov_proposal @ self.grad_f_theta_opt)
    f_target_theta = bceloss(self.b_opt + self.X @ theta_0, self.Y.double()) \
                     + 1/(2.0) * theta_0 @ self.Cov_prior_inv @ theta_0

    thetas = torch.zeros(n_iterations, self.dimension)
    thetas[0] = theta_0
    for t in range(1, n_iterations):
      # Record iteration time
      t0 = time.time()
      xi = torch.zeros(self.dimension).normal_(0, 1)
      theta_new = self.theta_opt - self.Cov_proposal @ self.grad_f_theta_opt \
                  + self.Cov_proposal_L @ xi

      # MH step
      f_proposal_theta_new = 1/(2.0) * xi.pow(2).sum()
      f_target_theta_new = bceloss(self.b_opt + self.X @ theta_new, self.Y.double()) \
                           + 1/(2.0) * theta_new @ self.Cov_prior_inv @ theta_new
      u_sample = torch.zeros(1).uniform_(0, 1)
      if torch.log(u_sample) <= f_proposal_theta_new - f_target_theta_new + f_target_theta - f_proposal_theta:  
        thetas[t] = theta_new

        # Update the previous iteration values if accepted
        f_proposal_theta = f_proposal_theta_new
        f_target_theta = f_target_theta_new

        accepts[t] = 1
      else:
        thetas[t] = thetas[t-1]

      # Record iteration time
      t1 = time.time()
      iteration_times[t] = t1 - t0
      return self.b_opt, thetas, accepts, iteration_times



###
# HMC sampler
###
def hmc_bayesian_logistic_regression(bias, X, Y, sigma2_prior,
                                     n_iterations, h, sigma2_hmc, n_leapfrogs):
  accepts = torch.zeros(n_iterations)
  iteration_times = torch.zeros(n_iterations)

  bceloss = torch.nn.BCEWithLogitsLoss(reduction="sum")
  n_dimension = X.size(1)
  thetas = torch.zeros(n_iterations, n_dimension)
  ps = torch.zeros(n_iterations, n_dimension)

  # Compute the previous theta using the opt
  theta_0 = thetas[0]
  f_theta = bceloss(bias + X @ theta_0, Y.double()) \
            + 1/(2.0 * sigma2_prior) * theta_0.pow(2).sum()
  
  for t in range(1, n_iterations):
    # Record iteration time
    t0 = time.time()

    # Run the leapfrog numerical integrator
    p_0 = torch.zeros(n_dimension).normal_(0, 1)
    p_new = p_0
    theta_new = thetas[t - 1]
    for l in range(0, n_leapfrogs):  
      # p step
      grad_f_theta = X.T @ (torch.sigmoid(bias + X @ theta_new) - Y) \
                     + 1/(sigma2_prior) * theta_new
      p_new = p_new - h/2 * grad_f_theta

      # theta step
      theta_new = theta_new + h/sigma2_hmc * p_new

      # p step
      grad_f_theta = X.T @ (torch.sigmoid(bias + X @ theta_new) - Y) \
                     + 1/(sigma2_prior) * theta_new
      p_new = p_new - h/2 * grad_f_theta

    # MH Step
    f_theta_new = bceloss(bias + X @ theta_new, Y.double()) \
                  + 1/(2.0 * sigma2_prior) * theta_new.pow(2).sum()

    H_theta = f_theta + 1/(2.0 * sigma2_hmc) * p_0.pow(2).sum()              
    H_theta_new = f_theta_new + 1/(2.0 * sigma2_hmc) * p_new.pow(2).sum()
    u_sample = torch.zeros(1).uniform_(0, 1)
    if torch.log(u_sample) <= H_theta - H_theta_new:  
      thetas[t] = theta_new

      # Update the previous iteration values if accepted
      f_theta = f_theta_new

      accepts[t] = 1
    else:
      thetas[t] = thetas[t-1]

    # Record iteration time
    t1 = time.time()
    iteration_times[t] = t1 - t0

  return thetas, accepts, iteration_times



###
# Simulations
###
torch.manual_seed(5)
torch.set_default_dtype(torch.float64)
torch.autograd.set_grad_enabled(False)

n_iterations = 10**(4)

dimensions_list = [50, 100, 150, 200, 250, 300]
samples_list = [int(1/10 * d) for d in dimensions_list]
n_reps = len(dimensions_list)

avg_iteration_times_cmhi = torch.zeros(n_reps)
avg_iteration_times_mala = torch.zeros(n_reps)
avg_iteration_times_hmc = torch.zeros(n_reps)

avg_accepts_cmhi = torch.zeros(n_reps)
avg_accepts_mala = torch.zeros(n_reps)
avg_accepts_hmc = torch.zeros(n_reps)





for rep in range(0, n_reps):
  n_features = dimensions_list[rep]
  n_samples = samples_list[rep]
  sigma2_model = 1/n_samples

  # slightly smaller than the theory says
  sigma2_prior = 1/n_features 
  C_prior = sigma2_prior* torch.eye(n_features)

  # Generate data
  print("SIMULATION: n, d =", (n_samples, n_features))
  b_true = 1
  theta_true = torch.zeros(n_features).uniform_(-1, 1)
  X = torch.zeros(n_samples, n_features).normal_(0, sigma2_model**(1/2.0))
  Y = torch.zeros(n_samples, dtype=torch.long)
  prob = torch.sigmoid(b_true + X @ theta_true)
  for i in range(0, Y.size(0)):
    Y[i] = torch.bernoulli(prob[i])

  ######
  # CMHI Sampler
  ######
  print("Running CMHI")
  bayesian_logistic_regression = BayesianLogisticRegression(X, Y, Cov_prior = C_prior)
  b_opt, thetas, accepts, iteration_times = bayesian_logistic_regression.sample(n_iterations = n_iterations)
  print("Done.")
  
  avg_iteration_times_cmhi[rep] = iteration_times.mean()
  avg_accepts_cmhi[rep] = accepts.mean()

  print("avg accepts:", avg_accepts_cmhi[rep].item())
  print("avg iteration time:", avg_iteration_times_cmhi[rep].item())
  print("-----------------------")


  # Total integration length for hmc
  h_mala = 1/n_features**(1/3.)

  ######
  # MALA Sampler
  ######
  print("Running MALA")
  thetas_mala, accepts_mala, iteration_times_mala = hmc_bayesian_logistic_regression(bias = b_opt,
                                                                                  X = X, Y = Y, sigma2_prior = sigma2_prior,
                                                                                  n_iterations = n_iterations, h = h_mala, 
                                                                                  n_leapfrogs = 1, sigma2_hmc = h_mala)
  print("Done.")

  avg_iteration_times_mala[rep] = iteration_times_mala.mean()
  avg_accepts_mala[rep] = accepts_mala.mean()

  print("avg accept:", avg_accepts_mala[rep].item())
  print("avg iteration time:", avg_iteration_times_mala[rep].item())
  print("-----------------------")

  ######
  # HMC Sampler
  ######
  h_hmc = 1/n_features**(1/4.)
  n_leapfrogs = 10

  print("Running HMC")
  thetas_hmc, accepts_hmc, iteration_times_hmc = hmc_bayesian_logistic_regression(bias = b_opt,
                                                                                  X = X, Y = Y, sigma2_prior = sigma2_prior,
                                                                                  n_iterations = n_iterations, h = h_hmc, 
                                                                                  n_leapfrogs = n_leapfrogs, sigma2_hmc = h_hmc)
  print("Done.")

  avg_iteration_times_hmc[rep] = iteration_times_hmc.mean()
  avg_accepts_hmc[rep] = accepts_hmc.mean()

  print("n accepts:", accepts_hmc.sum().item())
  print("avg accept:", avg_accepts_hmc[rep].item())
  print("avg iteration time:", avg_iteration_times_hmc[rep].item())
  print("-----------------------")


###
# Plots
###
iterations = torch.arange(0, n_iid)
samples_and_dimensions = list(zip(dimensions_list, samples_list))

linewidth = 3
markersize = 8
alpha = .8

red_color = (0.86, 0.3712, 0.33999999999999997)
blue_color = (0.33999999999999997, 0.43879999999999986, 0.86)
green_color = (0.17254901960784313, 0.6274509803921569, 0.17254901960784313)
purple_color = (0.5803921568627451, 0.403921568627451, 0.7411764705882353)

###
# Plot iteration times
###
plt.clf()
plt.style.use("ggplot")
plt.figure(figsize=(10, 8))

plt.plot(avg_iteration_times_mala.cpu().numpy(), 
         '-', alpha = alpha, marker="p", markersize=markersize, color=red_color, label="MALA", linewidth = linewidth)

plt.plot(avg_iteration_times_hmc.cpu().numpy(), 
         '-', alpha = alpha, marker="p", markersize=markersize, color=green_color, label="HMC", linewidth = linewidth)

plt.plot(avg_iteration_times_cmhi.cpu().numpy(), 
         '-', alpha = alpha, marker="v", markersize=markersize, color=blue_color, label="MHI", linewidth = linewidth)


plt.tick_params(axis='x', labelsize=20)
plt.tick_params(axis='y', labelsize=20)
plt.xticks(iterations, samples_and_dimensions)
plt.xlabel(r"The dimension and sample size: d, n", fontsize = 25, color="black")
plt.ylabel(r"Average iteration time (seconds)", fontsize = 25, color="black")
plt.legend(loc="best", fontsize=25, borderpad=.05, framealpha=0)
plt.savefig("avg_iteration_times_plot.png", pad_inches=0, bbox_inches='tight',)


###
# Plot iteration times
###
plt.clf()
plt.style.use("ggplot")
plt.figure(figsize=(10, 8))

plt.plot(avg_accepts_mala.cpu().numpy(), 
         '-', alpha = alpha, marker="p", markersize=markersize, color=red_color, label="MALA", linewidth = linewidth)

plt.plot(avg_accepts_hmc.cpu().numpy(), 
         '-', alpha = alpha, marker="p", markersize=markersize, color=green_color, label="HMC", linewidth = linewidth)

plt.plot(avg_accepts_cmhi.cpu().numpy(), 
         '-', alpha = alpha, marker="v", markersize=markersize, color=blue_color, label="MHI", linewidth = linewidth)


plt.tick_params(axis='x', labelsize=20)
plt.tick_params(axis='y', labelsize=20)
plt.xticks(iterations, samples_and_dimensions)
plt.xlabel(r"The dimension and sample size: d, n", fontsize = 25, color="black")
plt.ylabel(r"Average iteration time (seconds)", fontsize = 25, color="black")
plt.legend(loc="best", fontsize=25, borderpad=.05, framealpha=0)
plt.savefig("avg_accepts_plot.png", pad_inches=0, bbox_inches='tight',)

