import torch

#from cmhi import BayesianLogisticRegression

class BayesianLogisticRegression:
  # Gradient descent with annealing step sizes
  @staticmethod
  def graddescent(X, Y, sigma2_prior, C, 
                  stepsize = .1, tol = 10**(-10), max_iterations = 10**5):
    C_half = torch.linalg.cholesky(C)
    C_inv = torch.cholesky_inverse(C_half)
    bceloss = torch.nn.BCEWithLogitsLoss(reduction="sum")

    b = torch.zeros(1)
    theta = torch.zeros(X.size(1))

    old_loss = bceloss(b + X @ theta, Y.double()) \
               + 1/(2.0 * sigma2_prior) * theta @ C_inv @ theta

    for t in range(1, max_iterations):
      grad_loss_b = torch.ones(X.size(0)) @ (torch.sigmoid(b + X @ theta) - Y)
      grad_loss_theta = X.T @ (torch.sigmoid(b + X @ theta) - Y) + 1/(sigma2_prior) * C_inv @ theta

      if torch.any(torch.isnan(grad_loss_b)) or torch.any(torch.isnan(grad_loss_theta)):
        raise Exception("NAN value in gradient descent.")
      else:
        b_new = b - stepsize * grad_loss_b
        theta_new = theta - stepsize * grad_loss_theta
        new_loss = bceloss(b_new + X @ theta_new, Y.double()) \
                   + 1/(2.0 * sigma2_prior) * theta_new @ C_inv @ theta_new
        
        # New loss worse than old loss? Reduce step size and try again.
        if (new_loss > old_loss):
          stepsize = stepsize * (.99)
        else:
          # Stopping criterion
          if (old_loss - new_loss) < tol:
            return b, theta

          # Update
          b = b_new
          theta = theta_new
          old_loss = new_loss

    raise Exception("Gradient descent failed to converge.")


  # MHI sampler using 'centered' proposal for Bayesian logistic regression
  def __init__(self, X, Y, sigma2_prior, 
               C, h = 1,
               stepsize_opt = .1, tol_opt = 10**(-10), max_iterations_opt = 10**5):
    self.dimension = X.size(1)
    self.X = X
    self.Y = Y
    self.sigma2_prior = sigma2_prior

    C_half = torch.linalg.cholesky(C)
    C_inv = torch.cholesky_inverse(C_half)

    self.C_half = C_half
    self.C_inv = C_inv
    self.h = h

    # Optimize target
    b_opt, theta_opt = BayesianLogisticRegression.graddescent(X, Y, sigma2_prior, C,
                                   stepsize_opt, tol_opt, max_iterations_opt)
    self.b_opt = b_opt
    self.theta_opt = theta_opt

  def sample(self, theta_0 = None, n_iterations = 1):
    accepts = torch.zeros(n_iterations)
    bceloss = torch.nn.BCEWithLogitsLoss(reduction="sum")

    if theta_0 is None:
      theta_0 = self.theta_opt
      f_proposal_theta = torch.zeros(1)
    else:
      f_proposal_theta = 1/(2.0 * self.h) * (theta_0 - self.theta_opt) @ self.C_inv @ (theta_0 - self.theta_opt)

    # Compute the previous theta using the opt
    f_target_theta = bceloss(self.b_opt + self.X @ theta_0, self.Y.double()) \
                     + 1/(2.0 * self.sigma2_prior) * theta_0 @ self.C_inv @ theta_0

    thetas = torch.zeros(n_iterations, self.dimension)
    thetas[0] = theta_0
    for t in range(1, n_iterations):
      xi = torch.zeros(self.theta_opt.size(0)).normal_(0, 1)
      theta_new = self.theta_opt + self.h**(1/2) * self.C_half @ xi

      # MH step
      f_proposal_theta_new = 1/(2.0) * xi.pow(2).sum()
      f_target_theta_new = bceloss(self.b_opt + self.X @ theta_new, self.Y.double()) \
                           + 1/(2.0 * self.sigma2_prior) * theta_new @ self.C_inv @ theta_new
      u_sample = torch.zeros(1).uniform_(0, 1)
      if torch.log(u_sample) <= f_proposal_theta_new - f_target_theta_new + f_target_theta - f_proposal_theta:  
        thetas[t] = theta_new

        # Update the previous iteration values if accepted
        f_proposal_theta = f_proposal_theta_new
        f_target_theta = f_target_theta_new

        accepts[t] = 1
      else:
        thetas[t] = thetas[t-1]

    return self.b_opt, thetas, accepts

  def sample_until_accept(self, theta_0 = None, max_iterations = 10**(5)):
    bceloss = torch.nn.BCEWithLogitsLoss(reduction="sum")

    if theta_0 is None:
      theta_0 = self.theta_opt
      f_proposal_theta = torch.zeros(1)
    else:
      f_proposal_theta = 1/(2.0 * self.h) * (theta_0 - self.theta_opt) @ self.C_inv @ (theta_0 - self.theta_opt)

    # Compute the previous theta using the opt
    f_target_theta = bceloss(self.b_opt + self.X @ theta_0, self.Y.double()) \
                     + 1/(2.0 * self.sigma2_prior) * theta_0 @ self.C_inv @ theta_0

    for t in range(1, max_iterations):
      xi = torch.zeros(self.theta_opt.size(0)).normal_(0, 1)
      theta_new = self.theta_opt + self.h**(1/2) * self.C_half @ xi

      # MH step
      f_proposal_theta_new = 1/(2.0) * xi.pow(2).sum()
      f_target_theta_new = bceloss(self.b_opt + self.X @ theta_new, self.Y.double()) \
                           + 1/(2.0 * self.sigma2_prior) * theta_new @ self.C_inv @ theta_new
      u_sample = torch.zeros(1).uniform_(0, 1)
      if torch.log(u_sample) <= f_proposal_theta_new - f_target_theta_new + f_target_theta - f_proposal_theta:  
        return self.b_opt, theta_new

    raise Exception("Failed to accept from the proposal.")



# Upper bound estimate of the Wasserstein distance empirically using the synchronous coupling
def estimate_wasserstein(X, Y, sigma2_prior, C,
                         b_opt, theta_opt, theta_target, 
                         n_iterations, h):
  bceloss = torch.nn.BCEWithLogitsLoss(reduction="sum")
  C_half = torch.linalg.cholesky(C)
  C_inv = torch.cholesky_inverse(C_half)

  thetas = torch.zeros(n_iterations, X.size(1))
  thetas_target = torch.zeros(n_iterations, X.size(1))

  f_theta = bceloss(b_opt + X @ theta_opt, Y.double()) \
            + 1/(2.0 * sigma2_prior) * theta_opt @ C_inv @ theta_opt
  f_proposal_theta = torch.zeros(1)
  
  f_theta_target = bceloss(b_opt + X @ theta_target, Y.double()) \
                   + 1/(2.0 * sigma2_prior) * theta_target @ C_inv @ theta_target
  f_proposal_theta_target =  1/(2.0 * h) * (theta_target - theta_opt) @ C_inv @ (theta_target - theta_opt)
  
  thetas[0] = theta_opt
  thetas_target[0] = theta_target
  for t in range(1, n_iterations):
    xi = torch.zeros(theta_opt.size(0)).normal_(0, 1)
    theta_new = theta_opt + h**(1/2) * C_half @ xi

    # MH step
    u_sample = torch.zeros(1).uniform_(0, 1)
    f_proposal_theta_new = 1/(2.0) * xi.pow(2).sum()
    f_theta_new = bceloss(b_opt + X @ theta_new, Y.double()) \
                  + 1/(2.0 * sigma2_prior) * theta_new @ C_inv @ theta_new

    both_accepted = True
    if torch.log(u_sample) <= f_theta - f_theta_new + f_proposal_theta_new - f_proposal_theta:  
      thetas[t] = theta_new

      # Update the previous iteration values if accepted
      f_proposal_theta = f_proposal_theta_new
      f_theta = f_theta_new
    else:
      both_accepted = False
      thetas[t] = thetas[t-1]

    if torch.log(u_sample) <= f_theta_target - f_theta_new + f_proposal_theta_new - f_proposal_theta_target:  
      thetas_target[t] = theta_new

      # Update the previous iteration values if accepted
      f_proposal_theta_target = f_proposal_theta_new
      f_theta_target = f_theta_new
    else:
      both_accepted = False
      thetas_target[t] = thetas_target[t-1]

    # If both have accepted, the chains have coalesced  
    if both_accepted:
      return 0.0

  return torch.norm(thetas[-1] - thetas_target[-1]).item()



###
# HMC sampler
###
def estimate_wasserstein_hmc(X, Y, sigma2_prior, C,
                             b_opt, theta_opt, theta_target, 
                             n_iterations, h, n_leapfrogs,
                             sigma2_hmc = 1):
  
  bceloss = torch.nn.BCEWithLogitsLoss(reduction="sum")
  n_dimension = X.size(1)
  thetas = torch.zeros(n_iterations, n_dimension)
  thetas_target = torch.zeros(n_iterations, n_dimension)

  ps = torch.zeros(n_iterations, n_dimension)
  ps_target = torch.zeros(n_iterations, n_dimension)


  theta_0 = thetas[0]
  thetas_target_0 = theta_target

  f_theta = bceloss(b_opt + X @ theta_0, Y.double()) \
            + 1/(2.0 * sigma2_prior) * theta_0.pow(2).sum()
  f_theta_target = bceloss(b_opt + X @ thetas_target_0, Y.double()) \
                   + 1/(2.0 * sigma2_prior) * thetas_target_0.pow(2).sum()

  for t in range(1, n_iterations):
    # Run the leapfrog numerical integrator
    p_0 = torch.zeros(n_dimension).normal_(0, 1)
    p_new = p_0
    p_target_new = p_0

    theta_new = thetas[t - 1]
    theta_target_new = thetas[t - 1]
    for l in range(0, n_leapfrogs):  
      # p step
      grad_f_theta = X.T @ (torch.sigmoid(b_opt + X @ theta_new) - Y) \
                     + 1/(sigma2_prior) * theta_new
      p_new = p_new - h/2 * grad_f_theta

      # p step
      grad_f_theta_target = X.T @ (torch.sigmoid(b_opt + X @ theta_target_new) - Y) \
                     + 1/(sigma2_prior) * theta_target_new
      p_target_new = p_target_new - h/2 * grad_f_theta_target

      # theta step
      theta_new = theta_new + h/sigma2_hmc * p_new
      theta_target_new = theta_target_new + h/sigma2_hmc * p_target_new

      # p step
      grad_f_theta = X.T @ (torch.sigmoid(b_opt + X @ theta_new) - Y) \
                     + 1/(sigma2_prior) * theta_new
      p_new = p_new - h/2 * grad_f_theta

      grad_f_theta_target = X.T @ (torch.sigmoid(b_opt + X @ theta_target_new) - Y) \
                            + 1/(sigma2_prior) * theta_target_new
      p_target_new = p_target_new - h/2 * grad_f_theta_target

    # MH Step
    f_theta_new = bceloss(b_opt + X @ theta_new, Y.double()) \
                  + 1/(2.0 * sigma2_prior) * theta_new.pow(2).sum()

    f_theta_target_new = bceloss(b_opt + X @ theta_target_new, Y.double()) \
                  + 1/(2.0 * sigma2_prior) * theta_target_new.pow(2).sum()

    H_theta = f_theta + 1/(2.0 * sigma2_hmc) * p_0.pow(2).sum()              
    H_theta_new = f_theta_new + 1/(2.0 * sigma2_hmc) * p_new.pow(2).sum()

    H_theta_target = f_theta_target + 1/(2.0 * sigma2_hmc) * p_0.pow(2).sum()              
    H_theta_target_new = f_theta_target_new + 1/(2.0 * sigma2_hmc) * p_target_new.pow(2).sum()

    u_sample = torch.zeros(1).uniform_(0, 1)
    if torch.log(u_sample) <= H_theta - H_theta_new:  
      thetas[t] = theta_new
    else:
      thetas[t] = thetas[t-1]

    if torch.log(u_sample) <= H_theta_target - H_theta_target_new:  
      thetas_target[t] = theta_target_new

      # Update the previous iteration values if accepted
      f_theta_target = f_theta_target_new
    else:
      thetas_target[t] = thetas_target[t-1]

  return torch.norm(thetas[-1] - thetas_target[-1]).item()



def run_sim(sigma2_prior):
  wasserstein_estimates = torch.zeros(n_simulations)
  std_wasserstein_estimates = torch.zeros(n_simulations)

  wasserstein_estimates_hmc = torch.zeros(n_simulations)
  std_wasserstein_estimates_hmc = torch.zeros(n_simulations)
  
  for sim in range(0, n_simulations):
    n_features = dimensions_list[sim]
    n_samples = samples_list[sim]
    sigma2_model = 1/n_samples

    # Generate data
    print("SIMULATION: n, d =", (n_samples, n_features))
    b_true = 1
    theta_true = torch.zeros(n_features).uniform_(-2, 2)
    X = torch.zeros(n_samples, n_features).normal_(0, sigma2_model**(1/2.0))
    Y = torch.zeros(n_samples, dtype=torch.long)
    prob = torch.sigmoid(b_true + X @ theta_true)
    for i in range(0, Y.size(0)):
      Y[i] = torch.bernoulli(prob[i])

    C = 1/n_features * torch.eye(n_features)
    h = .8 * sigma2_prior
    bayesian_logistic_regression = BayesianLogisticRegression(X, Y, sigma2_prior, 
                                                              C, h)
    unbiased_wasserstein_estimates = torch.zeros(n_iid)
    unbiased_wasserstein_estimates_hmc = torch.zeros(n_iid)
    for j in range(0, n_iid):
      print("Estimating Wasserstein", j + 1, "of", n_iid)
      # Generate a sample using CMHI sampler
      b_opt, theta_target = bayesian_logistic_regression.sample_until_accept()

      unbiased_wasserstein_estimates[j] = estimate_wasserstein(X, Y, sigma2_prior, C,
                                                               b_opt = bayesian_logistic_regression.b_opt, 
                                                               theta_opt = bayesian_logistic_regression.theta_opt, 
                                                               theta_target = theta_target, 
                                                               n_iterations = n_iterations, 
                                                               h = h)

      unbiased_wasserstein_estimates_hmc[j] = estimate_wasserstein_hmc(X, Y, sigma2_prior, C,
                                                               b_opt = bayesian_logistic_regression.b_opt, 
                                                               theta_opt = bayesian_logistic_regression.theta_opt, 
                                                               theta_target = theta_target, 
                                                               n_iterations = n_iterations, 
                                                               h = .1,
                                                               n_leapfrogs = 10)

    wasserstein_estimates[sim] = unbiased_wasserstein_estimates.mean(0)
    std_wasserstein_estimates[sim] = unbiased_wasserstein_estimates.std(0)

    wasserstein_estimates_hmc[sim] = unbiased_wasserstein_estimates_hmc.mean(0)
    std_wasserstein_estimates_hmc[sim] = unbiased_wasserstein_estimates_hmc.std(0)

    print("Wasserstein estimate:", wasserstein_estimates[sim].item())

  return wasserstein_estimates, std_wasserstein_estimates, wasserstein_estimates_hmc, std_wasserstein_estimates_hmc



###
# Simulations
###
torch.manual_seed(5)
torch.set_default_dtype(torch.float32)
torch.autograd.set_grad_enabled(False) 

n_iid = 2
n_iterations = 10**(4)

dimensions_list = [10, 20, 30]
samples_list = [int(1/10 * d) for d in dimensions_list]
n_simulations = len(dimensions_list)


# Smaller prior variance
sigma2_prior = 10**(1)
print("Simulating for sigma2_prior = ", sigma2_prior)
print("--------------------------------")
wasserstein_estimates, std_wasserstein_estimates, wasserstein_estimates_hmc, std_wasserstein_estimates_hmc = run_sim(sigma2_prior)


###
# Plot
###
import matplotlib.pyplot as plt
from matplotlib import rc
import seaborn as sns


iterations = torch.arange(0, n_simulations)
samples_and_dimensions = list(zip(dimensions_list, samples_list))

linewidth = 3
markersize = 8
alpha = .8

light_blue_color = (3./255, 37./255, 76./255)
dark_blue_color = (24./255, 123./255, 205./255)


plt.clf()
plt.style.use("ggplot")
plt.figure(figsize=(10, 8))

plt.plot(iterations, mean_wasserstein_estimates1.cpu().numpy(), 
         '-', alpha = alpha, marker="v", markersize=markersize, color=dark_blue_color, label=r"$\sigma^2_0 = 10^{-1}$", linewidth = linewidth)
plt.fill_between(iterations, mean_wasserstein_estimates - std_wasserstein_estimates/n_iid**(1/2.),
                 mean_wasserstein_estimates + std_wasserstein_estimates/n_iid**(1/2.), alpha=0.1,
                 color=dark_blue_color)

plt.plot(iterations, mean_wasserstein_estimates_hmc.cpu().numpy(), 
         '-', alpha = alpha, marker="v", markersize=markersize, color=light_blue_color, label=r"$\sigma^2_0 = 10^4$", linewidth = linewidth)
plt.fill_between(iterations, mean_wasserstein_estimates_hmc - std_wasserstein_estimates_hmc/n_iid**(1/2.),
                 mean_wasserstein_estimates_hmc + std_wasserstein_estimates_hmc/n_iid**(1/2.), alpha=0.1,
                 color=light_blue_color)

plt.tick_params(axis='x', labelsize=20)
plt.tick_params(axis='y', labelsize=20)
plt.xticks(iterations, samples_and_dimensions)
plt.xlabel(r"The dimension and sample size: d, n", fontsize = 25, color="black")
plt.ylabel(r"Estimated Wasserstein distance", fontsize = 25, color="black")
plt.legend(loc="best", fontsize=25, borderpad=.05, framealpha=0)
plt.savefig("wasserstein_plot.png", pad_inches=0, bbox_inches='tight',)

